
import Login from './pages/Login'
import Signup from './pages/Signup'
import Landing from './pages/Landing'
import Dashboard from './pages/Dashboard'
import { Route, Routes } from "react-router-dom";
import AuthRoute from './components/AuthRoute';
import Bill_dash from './pages/Bill_dash';
import Biz_dash from './pages/Biz_dash';
import Contact_dash from './pages/Contact_dash'
import Refer_dash from './pages/Refer_dash'


function App() {
  return (
    <div>


      <Routes>
        <Route element={<AuthRoute />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/billing" element={<Bill_dash />} />
          <Route path="/business-profile" element={<Biz_dash />} />
          <Route path="/contact-us" element={<Contact_dash />} />
          <Route path="/refer" element={<Refer_dash />} />
        </Route>

        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />


      </Routes>


    </div>
  );
}

export default App;
