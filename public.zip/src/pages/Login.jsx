import React from 'react'
import { LockOutlined, UserOutlined } from '@ant-design/icons';
import { Button, Checkbox, Form, Input } from 'antd';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from "react";
import logo from '../assets/images/tandem_logo.svg'
import { Alert } from 'antd';
import './Login.css'
import { useAuth } from '../context/AuthProvider';





const Login = () => {

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate();
    const { login, user } = useAuth();


    const handleSubmit = async (e) => {

        try {
            setError("");
            setLoading(true);
            const {
                data: { user, session },
                error
            } = await login(e.email, e.password);
            console.log(user);
            if (error) setError(error.message);
            console.log(error);
            if (user && session) navigate("/dashboard");
        } catch (error) {
            setError("Email or Password Incorrect");
        }
        setLoading(false);


    }



    return (
        <div className='bg-gray-200 py-5 px-8'>
            <Link to={"/"}>
                <img className='' src={logo} alt="tandem_img" />
            </Link>

            <section className='font-Poppins w-full h-[calc(100vh-78px)] bg-gray-200 flex justify-center items-center'>
                <div className='bg-gray-100 w-[320px] tab:w-[368px] lap:w-[400px] py-5 px-10 rounded-lg shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px]'>
                    <Form
                        name="normal_login"
                        className="login-form"
                        initialValues={{
                            remember: true,
                        }}
                        onFinish={handleSubmit}
                    >
                        <h1 className='text-3xl lap:text-5xl font-bold mb-10 text-center'>Login</h1>
                        <Form.Item
                            name="email"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Email or Number!',
                                },
                            ]}
                        >
                            <Input
                                className='shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] text-sm rounded-md px-3 w-60 tab:w-72 lap:w-80 m-auto h-10 placeholder:font-Poppins placeholder:tracking-wide'
                                prefix={<UserOutlined className="site-form-item-icon" />} placeholder="Enter your email or phone no." />
                        </Form.Item>

                        <Form.Item
                            name="password"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your password!',
                                },
                            ]}
                        >
                            <Input.Password
                                className='shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] text-sm rounded-md px-3 w-60 tab:w-72 lap:w-80 m-auto h-10 placeholder:font-Poppins placeholder:tracking-wide'
                                prefix={<LockOutlined className="site-form-item-icon" />}
                                placeholder="Password"
                            />
                        </Form.Item>

                        <Form.Item className='flex justify-between'>
                            <Form.Item name="remember" valuePropName="checked" noStyle>
                                <Checkbox>Remember me</Checkbox>
                            </Form.Item>

                            <a className="login-form-forgot tab:ml-5 lap:ml-12" href="">
                                Forgot password ?
                            </a>
                        </Form.Item>

                        {/* Error message */}
                        {
                            error && <Alert
                                className='w-60 tab:w-72 lap:w-80 mb-7 h-fit'
                                message={error}
                                type="error"
                                showIcon
                                closable
                                onClose={() => setError("")}
                            />

                        }

                        <Form.Item>
                            <Button htmlType="submit" className="login-form-button bg-[#15213A] hover:bg-[#1e3055] shadow-lg shadow-blue-900/70 hover:shadow-blue-900/40 text-gray-300 w-60 tab:w-72 lap:w-80 h-9 mx-auto rounded-md font-Poppins tracking-wide border border-1 border-[#15213A]">
                                Log in
                            </Button>
                        </Form.Item>
                        <Form.Item className='text-center'>
                            Don't have an account? <Link to="/signup">Register here!</Link>
                        </Form.Item>
                    </Form>
                </div>
            </section>
        </div>
    )
}

export default Login